//
//  main.m
//  iphone
//
//  Created by Walzer on 10-11-16.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    int retVal = UIApplicationMain(argc, argv, nil, @"AppController");
    return retVal;
}
